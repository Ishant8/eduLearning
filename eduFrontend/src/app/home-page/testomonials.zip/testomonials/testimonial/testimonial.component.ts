import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: '[testimonial]',
  standalone: true,
  imports: [],
  templateUrl: './testimonial.component.html',
  styleUrl: './testimonial.component.css',
})
export class TestimonialComponent {

}
